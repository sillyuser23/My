require("dotenv").config();
const fs = require("fs");
const WebSocket = require("ws");

const GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json";
const PRIMARY_VOICE_CHANNEL_ID = "1541512013795303479";
const validStatuses = new Set(["online", "idle", "dnd", "invisible"]);
let stopping = false;

function loadTokens() {
  const numberedTokens = Object.entries(process.env)
    .filter(
      ([key, value]) =>
        /^DISCORD_(?:OAUTH_)?TOKEN_?\d+$/.test(key) &&
        typeof value === "string" &&
        value.trim(),
    )
    .sort(([first], [second]) => first.localeCompare(second))
    .map(([, value]) => value.trim());
  const listTokens = (process.env.DISCORD_OAUTH_TOKENS || "")
    .split(/[\s,]+/)
    .map((token) => token.trim())
    .filter(Boolean);
  return [
    ...new Set(
      [
        process.env.DISCORD_OAUTH_TOKEN,
        process.env.DISCORD_TOKEN,
        ...numberedTokens,
        ...listTokens,
      ]
        .filter(Boolean)
        .map((token) => token.trim()),
    ),
  ];
}

const TOKENS = loadTokens();

if (!TOKENS.length) {
  console.error(
    "DISCORD_OAUTH_TOKEN is missing. Add it to your existing environment settings and run again.",
  );
  process.exit(1);
}

function loadSettings() {
  try {
    return JSON.parse(fs.readFileSync("settings.json", "utf8"));
  } catch (error) {
    console.warn("Could not read settings.json; using environment defaults.");
    return {};
  }
}

const fileSettings = loadSettings();
const DISPLAY_NAME = "harrybot#4261";
const streamingSettings = fileSettings.streaming || {};
const rotationEntries = Array.isArray(fileSettings.presenceRotation?.entries)
  ? fileSettings.presenceRotation.entries
  : [];
const accountSettings = Array.isArray(fileSettings.accounts)
  ? fileSettings.accounts
  : [];
const voiceSettings = fileSettings.voice || {};
const config = {
  status: validStatuses.has(fileSettings.status)
    ? fileSettings.status
    : "online",
  customStatusText:
    fileSettings.customStatusText || process.env.CUSTOM_STATUS_TEXT || "",
  streamingEnabled: streamingSettings.enabled !== false,
  streamingName:
    streamingSettings.name || process.env.STREAMING_NAME || "Streaming now",
  streamingUrl:
    streamingSettings.url || process.env.STREAMING_URL || "https://twitch.tv/",
  voice: {
    enabled: voiceSettings.enabled === true,
    guildId: voiceSettings.guildId || "",
    channelId: voiceSettings.channelId || fileSettings.voiceChannelId || "",
    channels: Array.isArray(voiceSettings.channels)
      ? voiceSettings.channels
      : [],
    rejoinEveryMinutes: Number(voiceSettings.rejoinEveryMinutes) || 5,
    selfMute: voiceSettings.selfMute !== false,
    selfDeaf: voiceSettings.selfDeaf === true,
  },
};

const headers = {
  "Content-Type": "application/json",
  "User-Agent": "DiscordBot/1.0",
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function getVoiceChannels() {
  const guildId =
    config.voice.guildId || process.env.DISCORD_VOICE_GUILD_ID || "";
  return guildId ? [{ guildId, channelId: PRIMARY_VOICE_CHANNEL_ID }] : [];
}

function buildPresence(entry, fallback = config) {
  const current = entry || fallback;
  const activities = [];
  const stream = current.streaming || {};
  if ((stream.enabled ?? current.streamingEnabled) && stream.name !== "") {
    const activity = {
      type: 1,
      name: stream.name || current.streamingName,
      url: stream.url || current.streamingUrl,
    };
    if (stream.details) activity.details = stream.details;
    if (stream.state) activity.state = stream.state;
    activities.push(activity);
  }
  if (current.customStatusText) {
    activities.push({
      type: 4,
      name: "Custom Status",
      state: current.customStatusText,
    });
  }
  return {
    since: null,
    activities,
    status: validStatuses.has(current.status) ? current.status : "online",
    afk: false,
  };
}

function connectGateway(token, tokenIndex) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(GATEWAY_URL);
    let heartbeatTimer;
    let rotationTimer;
    let voiceRejoinTimer;
    let heartbeatAcknowledged = true;
    let settled = false;
    let rotationIndex = 0;

    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearInterval(heartbeatTimer);
      clearTimeout(rotationTimer);
      clearInterval(voiceRejoinTimer);
      error ? reject(error) : resolve();
    };

    const send = (payload) => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
    };

    const account = accountSettings[tokenIndex] || config;
    const accountRotation =
      account.presenceRotation || fileSettings.presenceRotation;
    const accountEntries = Array.isArray(accountRotation?.entries)
      ? accountRotation.entries
      : rotationEntries;
    const updatePresence = (entry) =>
      send({ op: 3, d: buildPresence(entry, account) });

    const schedulePresence = () => {
      if (!accountRotation?.enabled || !accountEntries.length) {
        updatePresence();
        return;
      }
      if (
        accountRotation.repeat === false &&
        rotationIndex >= accountEntries.length
      ) {
        return;
      }
      const entry = accountEntries[rotationIndex % accountEntries.length];
      rotationIndex += 1;
      updatePresence({
        status: entry.status,
        customStatusText: entry.customStatusText ?? account.customStatusText,
        streamingEnabled: entry.streaming?.enabled !== false,
        streamingName: entry.streaming?.name || account.streamingName,
        streamingUrl: entry.streaming?.url || account.streamingUrl,
        streaming: entry.streaming,
      });
      const minutes = Number(entry.durationMinutes);
      const durationMs =
        Number.isFinite(minutes) && minutes > 0
          ? minutes * 60 * 1000
          : 30 * 60 * 1000;
      rotationTimer = setTimeout(schedulePresence, durationMs);
    };

    const joinVoice = () => {
      if (!config.voice.enabled) return;
      const channels = getVoiceChannels();
      for (const channel of channels) {
        send({
          op: 4,
          d: {
            guild_id: channel.guildId,
            channel_id: channel.channelId,
            self_mute: config.voice.selfMute,
            self_deaf: config.voice.selfDeaf,
          },
        });
      }
    };

    const startVoiceKeepalive = () => {
      if (!config.voice.enabled || voiceRejoinTimer) return;
      voiceRejoinTimer = setInterval(
        joinVoice,
        Math.max(config.voice.rejoinEveryMinutes, 1) * 60 * 1000,
      );
    };

    ws.on("message", (raw) => {
      let message;
      try {
        message = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (message.op === 7) {
        ws.close(4000, "Discord requested reconnect");
        return;
      }
      if (message.op === 9) {
        finish(new Error("Discord rejected the session as invalid."));
        ws.close();
        return;
      }
      if (message.op === 11) {
        heartbeatAcknowledged = true;
        return;
      }
      if (message.op === 10) {
        const interval = message.d.heartbeat_interval;
        heartbeatTimer = setInterval(() => {
          if (!heartbeatAcknowledged) {
            ws.close(4000, "Heartbeat was not acknowledged");
            return;
          }
          heartbeatAcknowledged = false;
          send({ op: 1, d: null });
        }, interval);
        send({
          op: 2,
          d: {
            token,
            properties: {
              os: "linux",
              browser: "replit-bot",
              device: "replit-bot",
            },
            presence: null,
          },
        });
      }
      if (message.t === "READY") {
        schedulePresence();
        joinVoice();
        startVoiceKeepalive();
      }
      if (message.t === "RESUMED") {
        joinVoice();
      }
    });

    ws.on("error", (error) => finish(error));
    ws.on("close", (code) => {
      clearInterval(heartbeatTimer);
      finish();
    });
  });
}

async function runToken(token, tokenIndex) {
  let delay = 5000;
  while (!stopping) {
    try {
      await validateTokenFor(token);
      await connectGateway(token, tokenIndex);
      delay = 5000;
    } catch (error) {
      if (stopping) break;
    }
    if (!stopping) {
      await sleep(delay);
      delay = Math.min(delay * 2, 60000);
    }
  }
}

async function validateTokenFor(token) {
  const response = await fetch("https://discord.com/api/v10/users/@me", {
    headers: { ...headers, Authorization: token },
  });
  if (!response.ok) {
    throw new Error(`Discord rejected a token (HTTP ${response.status}).`);
  }
  return response.json();
}

async function main() {
  try {
    console.log(DISPLAY_NAME);
    await Promise.all(TOKENS.map((token, index) => runToken(token, index)));
  } catch (error) {
    console.error(
      error instanceof Error ? error.message : "Could not start the bot.",
    );
    process.exitCode = 1;
  }
}

process.once("SIGINT", () => {
  stopping = true;
  console.log("Stopping bot.");
});
process.once("SIGTERM", () => {
  stopping = true;
  console.log("Stopping bot.");
});
main();
